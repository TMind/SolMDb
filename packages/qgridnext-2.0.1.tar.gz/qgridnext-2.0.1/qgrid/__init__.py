import warnings
warnings.warn("qgird is an alias of qgridnext for backward compatibility. It is recommended to use `import qgridnext` instead.", DeprecationWarning, stacklevel=2)

from qgridnext import *
